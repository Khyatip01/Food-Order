<!--footer starts-->
<div class="footer">
   <div class="wrapper">
    <p class="text-center">2022 All Rights has been reserved,some restaurant. Developed By -<a href="#">Khyati Modi</a></p>
   </div>
    
   </div>
   <!--footer ends-->
    </html>